const Client = require('../model/clientModel')
const Agency = require('../model/agentModel')

const clientController = {
    //create a new client and adding it to agency
    Client : async (req,res) => {
        const {clientId, clientName, email, clientPhone, totalBill } = req.body;
        if (!clientId || !clientName || !email || !clientPhone || !totalBill) {
            return res.status(400).send('Missing required fields');
        }

        try {
            const agency = await Agency.findByIdAndUpdate( {_id : req.params.id },req.body);
            
            const client = await Client.create({
                agencyId: agency._id,
                clientId,
                name: clientName,
                email,
                phoneNumber: clientPhone,
                totalBill
            });
        
            agency.clients.push(client._id);
            await agency.save();
        
            res.status(201).json({ agency, client });
        } catch (err) {
            console.error(err);
            res.status(500).send(err.message);
        }
    },
    update : async (req,res)=>{
        try {  
            let data = await Client.findById({ _id: req.params.id })
                if(!data)
                    return res.status(404).json({ msg: "client doesn't exists."})
                
            let updated = await Client.findByIdAndUpdate({ _id: req.params.id }, req.body)
                res.status(200).json({ msg: "client updated successfully", client: updated })
            } catch (err) {
                return  res.status(500).json({ msg: err.message })
            }
    },
    delete : async (req,res)=>{
        try {
            let data = await Client.findById({ _id: req.params.id })
                if(!data)
                    return res.status(404).json({ msg: "client doesn't exists."})

                await Client.findByIdAndDelete({ _id: req.params.id })

                return res.status(200).json({ msg: "client deleted successfully"})
            
        } catch (err) {
            return  res.status(500).json({ msg: err.message })
        }
    }

}

module.exports = clientController