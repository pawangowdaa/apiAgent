const Agency = require('../model/agentModel');


const AgencyClient = {

    
    
    getAll : async(req,res) => {
        try {
            const agencies = await Agency.find().populate('clients');
            res.json(agencies);
          } catch (err) {
            console.error(err);
            res.status(500).send(err.message);
          }
    },
    getSingle: async(req,res) => {
        try {
            const agency = await Agency.findById(req.params.id).populate('clients');
                if (!agency) {
                    return res.status(404).send('Agency not found');
                }
                let topClients = agency.clients.sort((a, b) => b.totalBill - a.totalBill).slice(0);
                topClients = topClients.map(client => ({
                    clientName: client.name,
                    totalBill: client.totalBill
                }));
                res.json({
                    agencyName: agency.name,
                    topClients
                });
          } catch (err) {
            console.error(err);
            res.status(500).send(err.message);
          }
    },

    UpdateAgency : async(req,res) => {
        try {
            let data = await Agency.findById({ _id: req.params.id })
                if(!data)
                return res.status(404).json({ msg: "Agency doesn't exists."})
    
            const agency = await Agency.findByIdAndUpdate( {_id : req.params.id },req.body);
                res.status(200).json({ msg: "Agency updated successfully", agency: agency })
          
        } catch (err) {
            return  res.status(500).json({ msg: err.message })
        }
    },
    deleteAgency : async(req,res) => {
        try {
            let data = await Agency.findByIdAndDelete({ _id: req.params.id})
                if(!data)
                return res.status(404).json({ msg: "Agency doesn't exists."})

                res.status(200).json({ msg: "Agency Deleted successfully"})
        } catch (err) {
            return  res.status(500).json({ msg: err.message })
        }
    }
}

module.exports = AgencyClient