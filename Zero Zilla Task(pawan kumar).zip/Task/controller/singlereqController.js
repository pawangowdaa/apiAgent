const Agency = require('../model/agentModel');
const Client = require('../model/clientModel');

const signlereqController ={

// Create a new agency and client in a single request       
create : async(req,res) => {
    const {  name,  address_1, address_2, state, city, phoneNumber, clientName, email, clientPhone, totalBill, clientId } = req.body;

    if (!name || !address_1 || !state || !city || !phoneNumber || !clientName || !email || !clientPhone || !totalBill || !clientId) {
        return res.status(400).send('Missing required fields');
    }


    try {
        const agency = await Agency.create({
            name,
            address_1,
            address_2: req.body.address_2 || '',
            state,
            city,
            phoneNumber
        });
    
        const client = await Client.create({
            agencyId: agency._id,
            clientId,
            name: clientName,
            email,
            phoneNumber: clientPhone,
            totalBill
        });
    
        agency.clients.push(client._id);
        await agency.save();
    
        res.status(201).json({ agency, client });
    } catch (err) {
        console.error(err);
        res.status(500).send(err.message);
    }
}
}
module.exports = signlereqController