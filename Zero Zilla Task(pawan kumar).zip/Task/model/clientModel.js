const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const clientModule = new Schema({
  agencyId: {
    type: Schema.Types.ObjectId,
    ref: 'Agency',
    required: true
  },
    clientId:{
        type: Number,
        required : true,
        trim: true
    },
    name:{
        type: String,
        required : true,
        trim: true
    },
    email:{
        type: String,
        required : true,
        trim: true
    },
    totalBill:{
        type: String,
        required : true,
        trim: true
    },
    phoneNumber:{
        type: String,
        required : true,
        trim: true
    },
    isActive: {
        type: Boolean,
        default: true
    }
},
{
  collection:"client",
  timestamps:true
});

module.exports = mongoose.model('client', clientModule);
