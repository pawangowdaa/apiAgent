const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const agentModel = new Schema({
    name:{
        type: String,
        required : true,
        trim: true
    },
    address_1:{
        type: String,
        required : true,
        trim: true
    },
    address_2:{
        type: String,
        required : false,
        trim: true
    },
    state:{
        type: String,
        required : true,
        trim: true
    },
    city:{
        type: String,
        required : true,
        trim: true
    },
    phoneNumber:{
        type: String,
        required : true,
        trim: true
    },
    isActive: {
        type: Boolean,
        default: true
    },
    clients: [{
        type: Schema.Types.ObjectId,
        ref: 'client',
      }] 
},{
  collection:"Agency",
  timestamps:true
});

module.exports = mongoose.model('Agency', agentModel);
