const agentroute = require('express').Router()
const agentcontroller = require('../controller/agentControllers')



agentroute.get('/agent/all', agentcontroller.getAll)

agentroute.get('/agent/single/:id', agentcontroller.getSingle)



agentroute.patch('/agent/update/:id', agentcontroller.UpdateAgency)

agentroute.delete('/agent/delete/:id', agentcontroller.deleteAgency)


module.exports = agentroute