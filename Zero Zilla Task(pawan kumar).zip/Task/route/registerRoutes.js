const router = require('express').Router()
const authController = require('../controller/authControllers')
const auth = require('../middleware/auth')


router.post(`/auth/register`, authController.register)

router.post(`/auth/login`, authController.login)

router.get(`/auth/logout`, authController.logout)

router.get(`/auth/authtoken`, authController.authToken)

router.get(`/auth/currentuser`, auth , authController.currentUser)



module.exports = router