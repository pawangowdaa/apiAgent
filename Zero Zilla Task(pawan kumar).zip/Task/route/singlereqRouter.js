const singlereqRouter = require("express").Router()
const signlereqController = require("../controller/singlereqController")

  singlereqRouter.post('/create', signlereqController.create)

module.exports = singlereqRouter
