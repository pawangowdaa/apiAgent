const clientRoute = require('express').Router()
const clientController = require('../controller/clientControllers')

clientRoute.post('/client/create/:id', clientController.Client)

clientRoute.patch('/client/update/:id', clientController.update)

clientRoute.delete('/client/delete/:id', clientController.delete)

module.exports = clientRoute