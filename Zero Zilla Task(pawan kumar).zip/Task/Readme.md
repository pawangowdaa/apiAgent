## To check the database contents

### steps
1. Connect using `MongoDb compass` using the url address provided in `.env` file

### Please find the below `.env` link
mongodb+srv://pawan005:Thagopkthago@cluster0.hkuzml6.mongodb.net/test